# A2Z Creative Studio — integrated project upgrade

Prepared against ARonzapata-ops/A2Z-ai-studio main on November 13, 2026.

## Status

Prepared and tested locally. NOT applied to GitHub and NOT deployed to the existing app. GitHub rejected branch creation with HTTP 403, Resource not accessible by integration. The separately published A2Z Songbook has not been changed by this upgrade.

## Apply

Back up the current app's projects and download important voice samples first. Replace the repository-root index.html, sw.js, and manifest.webmanifest with the matching files in this package in one commit. Keep all backend files unchanged. GitHub Pages currently publishes the main branch root. After deployment, reload the app in Safari. Old browser records remain in the same IndexedDB database; this upgrade adds an assets store without deleting the projects or voices stores. Opening the new code under a different hostname does not transfer old browser data.

## Connected experience

- Song, Story, and Video projects with searchable cards, theme, clean/explicit label, special flag, and production stages.
- Lyrics, style, approved lines, custom constraints, notes, audio/video links, and ordered storyboard scenes in each project.
- Every project save captures a version. Compare lyrics side by side and restore a take into the working draft without deleting history.
- Suno checks for missing exact approved lines and the 5,000-character lyrics limit; copy full lyrics, style, or a writing-assistant brief. Custom constraints and Clean/Explicit labels require human review.
- Attach original files and download them again; preview supported audio, video, and images. Attach generated results to the active project.
- Retains voice recording/upload, WAV conversion, and the existing SoulX-Singer request flow.
- Complete backup includes projects, voice recordings, and attached media as a downloadable JSON file. Legacy text backup remains available.
- Import supports old A2Z text backups, complete backups, and the Songbook JSON export. Imported records receive new IDs so existing projects remain intact. Complete imports write atomically.
- Updated service-worker cache and network-first loading so newly deployed versions are picked up when online.

## Limits

This is the first integration of the existing app, not a complete production platform. Data stays in this device/browser and does not sync automatically with the separately hosted Songbook. There is no built-in AI lyric generator, video editor, or MP4 rendering engine. The storyboard plans a video. SoulX-Singer generation still needs the configured external backend, reference voice, and target guide; model output was not tested. Large media backups may exceed device memory/storage. Save explicitly; there is no autosave.

## Validation

Passed JavaScript syntax check and local browser checks for saving two versions, side-by-side comparison, missing-approved-line detection, and persistence/reopening after reload, including storyboard and constraints. Media attachment, complete backup round trip, microphone capture, and external generation have not received end-to-end browser tests. No iPhone hardware testing was performed.

## Original file identities

index.html: 4626b8d4750743151650175350827322db887d8b
sw.js: eed8cc51281c431f973bb941ea0b81a9d2b85220
manifest.webmanifest: 1efdd212db9255f9cdfdb4122df789873f77723b

Re-read current GitHub files and reconcile any changes before applying this package later.
