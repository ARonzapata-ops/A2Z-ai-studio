"""Development preview adapter; production still runs uvicorn server:app."""
import argparse
import uvicorn
p=argparse.ArgumentParser()
p.add_argument('--host',default='127.0.0.1')
p.add_argument('--port',type=int,default=4173)
p.add_argument('--strictPort',action='store_true')
a=p.parse_args()
uvicorn.run('server:app',host=a.host,port=a.port)
