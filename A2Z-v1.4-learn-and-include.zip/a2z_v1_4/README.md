# A2Z v1.4 — Learn & Include

An upgrade to the saved v1.3 FastAPI studio. Existing project APIs, owner access, PostgreSQL/SQLite storage, backup/restore and AI adapters are preserved. This package has not been installed on the live app.

## Run

```bash
pip install -r requirements.txt
# Configure A2Z_OWNER_KEY privately on your host.
uvicorn server:app --host 0.0.0.0 --port 8000
```

Open http://localhost:8000. Choose Create, Learn, or Accessible video. Learning and local media tools work without owner access; saving studio projects requires the owner key. Keep the service private: this is single-owner access, not student accounts.

## Learning

Seven starter activities cover math, science, art, the world, self-reflection, words/music, and ASL/Deaf culture. Each has Discover, Explore, and Go deeper activities, a creative task, and an external resource. This is a starter collection, not a complete curriculum or an assessment of age or ability.

Notes and completion stay in this browser/device. Download and restore learning backups separately from owner project backups. No names or birthdays are required. Shared-device users share local progress. Younger learners should use external resources with a trusted adult. Make a studio project transfers an activity and notes into a story project for saving through owner access.

The ASL pathway introduces language/culture and links to ASL University's visual lessons. It does not include original sign demonstrations or recognition. The collection has not been reviewed by Deaf educators. A full course needs Deaf-led development and review.

## Accessible video

1. Select a local main video and optional human signer's video.
2. Set the main-video second at which signing begins, size and left/right placement.
3. Add timed captions or import SRT/WebVTT. Include lyrics, speakers and meaningful sounds.
4. Play/seek the main video to preview captions and synchronized signer playback.
5. Download SRT/VTT, transcript and workspace JSON. Keep original media separately.
6. If unlocked, save the workspace to owner projects. Open it from Saved projects and reselect original videos. Owner backups preserve workspace text and settings.

Media stays local via browser object URLs. Workspace files store filenames, captions and settings, not media bytes. Playback depends on browser codecs. No automatic transcription, speech-to-sign translation, avatar generation or combined MP4 rendering is implemented. Caption sidecars need a compatible player/editor. The original five-second MP4 exporter still produces a basic background and does not render this workspace. Have fluent signers and Deaf viewers review meaning, framing, pacing and readability.

## Upgrade

Back up current code and download owner projects first. Replace v1.3 package files on the Python host, preserving secrets, DATABASE_URL, persistent data and any existing web/legacy folder. Restart; /api/health should report 1.4.0. No schema migration is needed. The original legacy editor is not bundled. Python cannot run on GitHub Pages.

Use DATABASE_URL for durable PostgreSQL metadata, or A2Z_DATA_DIR for persistent SQLite. Switching databases requires project export/restore. Back up local learning data before changing browser origins/domains. Uploaded video storage is not implemented.

Optional existing integrations remain A2Z_TEXT_API_URL, A2Z_TEXT_MODEL, A2Z_TEXT_API_KEY; A2Z_IMAGE_API_URL (HTTPS endpoint accepting inputs and returning image bytes), A2Z_IMAGE_API_KEY. No AI service is connected or charged by these additions.

## Checks

```bash
pip install pytest
PYTHONPATH=. python3 -m pytest tests -q
node --test tests/captions.test.mjs
```

Backend tests cover authorization, projects, backup/restore, accessibility workspace preservation and lesson routes. JavaScript tests cover timing validation and SRT/VTT parsing/round trips. Browser checks cover learning completion, learning-to-project transfer, caption editing and VTT export. Real signer footage synchronization, iOS playback, PostgreSQL hosting and live installation remain unverified.
