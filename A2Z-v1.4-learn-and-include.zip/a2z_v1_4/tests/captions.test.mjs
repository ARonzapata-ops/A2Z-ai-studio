import {test} from 'node:test';import assert from 'node:assert/strict';import {parseCaptions,serialize,validateCues} from '../web/captions.mjs';
const cues=[{start:0,end:1.234,text:'[Piano]'}, {start:1.234,end:65,text:'A story\nfor everyone.'}];
test('SRT and VTT retain text and millisecond timing',()=>{for(const f of ['srt','vtt'])assert.deepEqual(parseCaptions(serialize(cues,f)),cues)});
test('reject overlap, invalid and reversed times',()=>{for(const c of [[{start:2,end:1,text:'x'}],[{start:-1,end:1,text:'x'}],[{start:0,end:2,text:'x'},{start:1,end:3,text:'y'}],[{start:NaN,end:3,text:'x'}]])assert.throws(()=>validateCues(c))});
test('reject empty text and malformed import',()=>{assert.throws(()=>validateCues([{start:0,end:1,text:' '} ]));assert.throws(()=>parseCaptions('garbage'));assert.throws(()=>parseCaptions('00:70:00.000 --> 00:71:00.000\nHi'))});
test('supports BOM, CRLF, cue identifiers and VTT settings',()=>assert.deepEqual(parseCaptions('\uFEFFWEBVTT\r\n\r\nintro\r\n00:00.000 --> 00:01.234 align:start\r\n[Piano]'),[cues[0]]));
test('caption HTML remains text and is never evaluated by parser',()=>{const x=[{start:0,end:1,text:'<script>alert(1)</script>'}];assert.deepEqual(parseCaptions(serialize(x)),x)});
