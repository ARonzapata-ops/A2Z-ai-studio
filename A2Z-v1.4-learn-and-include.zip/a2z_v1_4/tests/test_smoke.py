import os, tempfile
os.environ['A2Z_DATA_DIR']=tempfile.mkdtemp(prefix='a2z-test-')
os.environ['A2Z_OWNER_KEY']='test-owner-secret'
from fastapi.testclient import TestClient
from server import app
c=TestClient(app,headers={'X-A2Z-Owner-Key':'test-owner-secret'})
def test_health():
 assert c.get('/api/health').status_code==200
def test_project_roundtrip():
 p=c.post('/api/projects',json={'title':'First Story','kind':'story','content':'Once upon a time'})
 assert p.status_code==200,p.text
 pid=p.json()['id']
 assert any(x['id']==pid for x in c.get('/api/projects').json())
 assert c.get(f'/api/projects/{pid}/export?format=txt').text=='Once upon a time'
 assert c.get(f'/api/projects/{pid}/export?format=svg').status_code==200
 assert c.delete(f'/api/projects/{pid}').status_code==200
def test_unconfigured_generation():
 r=c.post('/api/generate',json={'kind':'artwork','prompt':'A blue mountain'})
 assert r.status_code==503
def test_validation():
 assert c.post('/api/projects',json={'title':'bad','kind':'unknown','content':''}).status_code==422

def test_owner_auth():
 from fastapi.testclient import TestClient
 unauth=TestClient(app)
 assert unauth.get('/api/projects').status_code==401
 assert unauth.get('/api/backup').status_code==401
 assert c.get('/api/backup').json()['format']=='a2z-project-backup-v1'

def test_restore_backup():
 backup=c.get('/api/backup').json()
 original=len(c.get('/api/projects').json())
 r=c.post('/api/restore',json=backup)
 assert r.status_code==200,r.text
 assert r.json()['restored']==0
 assert len(c.get('/api/projects').json())==original

def test_restore_rejects_invalid():
 r=c.post('/api/restore',json={'format':'wrong','projects':[]})
 assert r.status_code==422

def test_learning_routes_and_depths():
 assert c.get('/learn.html').status_code==200
 assert c.get('/accessibility.html').status_code==200
 lessons=c.get('/lessons.json').json()
 assert {'math','science','art','world','self','story','asl'}=={x['id'] for x in lessons}
 assert all(set(x['steps'])=={'discover','explore','deepen'} for x in lessons)

def test_accessibility_workspace_project_and_backup():
 import json
 ws={'format':'a2z-accessibility-v1','title':'Signed story','media':{'main':'story.mp4','signer':'signer.mp4'},'settings':{'offset':1,'size':40,'position':'left','captionSize':28},'cues':[{'start':0,'end':3,'text':'[Piano] Hello'}]}
 r=c.post('/api/projects',json={'title':ws['title'],'kind':'video','content':json.dumps(ws)})
 assert r.status_code==200
 pid=r.json()['id']
 assert json.loads(c.get(f'/api/projects/{pid}/export?format=json').json()['content']['text'])==ws
 backup=c.get('/api/backup').json()
 c.delete('/api/projects/'+pid)
 assert c.post('/api/restore',json=backup).status_code==200
 restored=next(x for x in c.get('/api/projects').json() if x['id']==pid)
 assert json.loads(restored['content']['text'])==ws
 c.delete('/api/projects/'+pid)
