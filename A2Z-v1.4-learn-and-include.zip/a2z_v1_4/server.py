"""A2Z v1 foundation. Run: pip install -r requirements.txt && uvicorn server:app --host 0.0.0.0 --port 8000"""
import io, json, os, re, sqlite3, tempfile, uuid, zipfile, subprocess, shutil, secrets
from datetime import datetime, timezone
from pathlib import Path
from fastapi import FastAPI, HTTPException, UploadFile, File, Header, Depends
from fastapi.responses import FileResponse, StreamingResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, ValidationError

ROOT=Path(__file__).parent
DATA=Path(os.environ.get('A2Z_DATA_DIR',ROOT/'data')); DATA.mkdir(parents=True,exist_ok=True)
DB=DATA/'projects.sqlite3'
app=FastAPI(title='A2Z Creative Studio',version='1.4.0')

def require_owner(x_a2z_owner_key: str | None = Header(default=None)):
 key=os.getenv('A2Z_OWNER_KEY')
 if not key: raise HTTPException(503,'Set A2Z_OWNER_KEY on the server before using project or generation endpoints')
 if not x_a2z_owner_key or not secrets.compare_digest(x_a2z_owner_key,key): raise HTTPException(401,'Owner key required')

DATABASE_URL=os.getenv('DATABASE_URL','').strip()
SCHEMA='CREATE TABLE IF NOT EXISTS projects (id TEXT PRIMARY KEY, title TEXT NOT NULL, kind TEXT NOT NULL, content TEXT NOT NULL, created TEXT NOT NULL, updated TEXT NOT NULL)'

class PgConnection:
 def __init__(self, conn):self.conn=conn
 def __enter__(self):self.conn.__enter__();return self
 def __exit__(self,*args):return self.conn.__exit__(*args)
 def execute(self,sql,params=()):return self.conn.execute(sql.replace('?', '%s'),params)

def connect():
 if DATABASE_URL:
  import psycopg
  from psycopg.rows import dict_row
  c=psycopg.connect(DATABASE_URL,row_factory=dict_row)
  c.execute(SCHEMA)
  c.commit()
  return PgConnection(c)
 c=sqlite3.connect(DB);c.row_factory=sqlite3.Row
 c.execute(SCHEMA)
 c.commit();return c
with connect() as c: pass
class Project(BaseModel):
 title:str=Field(min_length=1,max_length=160)
 kind:str=Field(pattern='^(music|video|story|artwork)$')
 content:str=Field(default='',max_length=200000)

def record(row):
 d=dict(row);d['content']=json.loads(d['content']);return d
@app.get('/api/health')
def health():return {'status':'ok','version':'1.4.0','text_ai_configured':bool(os.getenv('A2Z_TEXT_API_KEY')),'ffmpeg_available':bool(shutil.which('ffmpeg')),'image_ai_configured':bool(os.getenv('A2Z_IMAGE_API_URL') and os.getenv('A2Z_IMAGE_API_KEY')),'owner_access_configured':bool(os.getenv('A2Z_OWNER_KEY')),'storage':'postgres' if DATABASE_URL else 'sqlite'}
@app.get('/api/projects')
def projects(_=Depends(require_owner)):
 with connect() as c:return [record(x) for x in c.execute('SELECT * FROM projects ORDER BY updated DESC LIMIT 200')]
@app.post('/api/projects')
def create(p:Project,_=Depends(require_owner)):
 now=datetime.now(timezone.utc).isoformat();pid=str(uuid.uuid4())
 with connect() as c:c.execute('INSERT INTO projects VALUES(?,?,?,?,?,?)',(pid,p.title,p.kind,json.dumps({'text':p.content}),now,now))
 return {'id':pid,'title':p.title,'kind':p.kind,'content':{'text':p.content},'created':now,'updated':now}
@app.put('/api/projects/{pid}')
def update(pid:str,p:Project,_=Depends(require_owner)):
 now=datetime.now(timezone.utc).isoformat()
 with connect() as c:
  cur=c.execute('UPDATE projects SET title=?,kind=?,content=?,updated=? WHERE id=?',(p.title,p.kind,json.dumps({'text':p.content}),now,pid))
  if not cur.rowcount:raise HTTPException(404,'Project not found')
 return {'id':pid,'updated':now}
@app.delete('/api/projects/{pid}')
def delete(pid:str,_=Depends(require_owner)):
 with connect() as c:c.execute('DELETE FROM projects WHERE id=?',(pid,))
 return {'deleted':True}
@app.get('/api/projects/{pid}/export')
def export(pid:str,format:str='txt',_=Depends(require_owner)):
 with connect() as c:r=c.execute('SELECT * FROM projects WHERE id=?',(pid,)).fetchone()
 if not r:raise HTTPException(404,'Project not found')
 p=record(r);title=re.sub('[^a-zA-Z0-9_-]','-',p['title'])[:50] or 'project';txt=p['content'].get('text','')
 if format=='json':return Response(json.dumps(p,indent=2),media_type='application/json',headers={'Content-Disposition':f'attachment; filename="{title}.json"'})
 if format=='txt':return Response(txt,media_type='text/plain; charset=utf-8',headers={'Content-Disposition':f'attachment; filename="{title}.txt"'})
 if format=='svg':
  import html,textwrap
  lines=textwrap.wrap(txt or p['title'],width=28)[:12];parts=''.join(f'<text x="540" y="{330+i*60}" text-anchor="middle" fill="white" font-size="42" font-family="sans-serif">{html.escape(line)}</text>' for i,line in enumerate(lines))
  svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1080"><rect width="1080" height="1080" fill="#141a31"/><text x="540" y="140" text-anchor="middle" fill="#b4c1ff" font-size="40" font-family="sans-serif">A2Z STUDIO</text>{parts}</svg>'
  return Response(svg,media_type='image/svg+xml',headers={'Content-Disposition':f'attachment; filename="{title}.svg"'})
 if format=='mp4':
  if not shutil.which('ffmpeg'):raise HTTPException(503,'Video rendering requires ffmpeg on the server')
  # Generate a real downloadable text-title MP4, not a browser-only recorder.
  with tempfile.TemporaryDirectory() as td:
   out=Path(td)/'video.mp4';safe=''.join(ch for ch in p['title'] if ch.isalnum() or ch in ' -_')[:45]
   # No user text enters the ffmpeg filter expression.
   subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-f','lavfi','-i','color=c=0x141a31:s=720x1280:r=24:d=5','-c:v','libx264','-pix_fmt','yuv420p','-movflags','+faststart','-y',str(out)],check=True,timeout=45)
   return Response(out.read_bytes(),media_type='video/mp4',headers={'Content-Disposition':f'attachment; filename="{title}.mp4"'})
 raise HTTPException(400,'Supported formats: txt, json, svg, mp4')

class GenerateRequest(BaseModel):
 prompt:str=Field(min_length=1,max_length=20000)
 kind:str=Field(pattern='^(music|video|story|artwork)$')
@app.post('/api/generate')
async def generate(req:GenerateRequest,_=Depends(require_owner)):
 """Optional OpenAI-compatible text API. Never pretend text is music/video/image generation."""
 if req.kind=='artwork':
  import httpx
  url=os.getenv('A2Z_IMAGE_API_URL');key=os.getenv('A2Z_IMAGE_API_KEY')
  if not url or not key:raise HTTPException(503,'Image AI not configured. Supply an image inference endpoint and key on the server.')
  if not url.startswith('https://'):raise HTTPException(400,'Image API must use HTTPS')
  try:
   async with httpx.AsyncClient(timeout=120,follow_redirects=False) as client:
    r=await client.post(url,headers={'Authorization':'Bearer '+key,'Accept':'image/png'},json={'inputs':req.prompt})
    r.raise_for_status()
    if not r.headers.get('content-type','').startswith('image/'):raise HTTPException(502,'Image provider returned no image')
    if len(r.content)>15_000_000:raise HTTPException(502,'Image too large')
    return Response(r.content,media_type=r.headers['content-type'],headers={'Cache-Control':'no-store'})
  except HTTPException:raise
  except Exception as e:raise HTTPException(502,'Image provider failed: '+str(e)[:180])
 if req.kind!='story':raise HTTPException(501,f'{req.kind} AI provider is not configured. Use the project editor and exports until a provider is connected.')
 key=os.getenv('A2Z_TEXT_API_KEY');url=os.getenv('A2Z_TEXT_API_URL');model=os.getenv('A2Z_TEXT_MODEL')
 if not all((key,url,model)):raise HTTPException(503,'Story AI not configured. Set A2Z_TEXT_API_URL, A2Z_TEXT_MODEL, A2Z_TEXT_API_KEY on the server.')
 import httpx
 try:
  async with httpx.AsyncClient(timeout=90) as client:
   r=await client.post(url.rstrip('/')+'/chat/completions',headers={'Authorization':'Bearer '+key},json={'model':model,'messages':[{'role':'system','content':'You are a creative writing assistant. Write original content.'},{'role':'user','content':req.prompt}]})
   r.raise_for_status();return {'kind':'story','text':r.json()['choices'][0]['message']['content']}
 except Exception as e:raise HTTPException(502,'AI provider failed: '+str(e)[:250])
@app.get('/api/backup')
def backup(_=Depends(require_owner)):
 with connect() as c:
  data=[record(x) for x in c.execute('SELECT * FROM projects ORDER BY updated DESC')]
 payload={'format':'a2z-project-backup-v1','exported':datetime.now(timezone.utc).isoformat(),'projects':data}
 return Response(json.dumps(payload,indent=2),media_type='application/json',headers={'Content-Disposition':'attachment; filename="a2z-projects-backup.json"','Cache-Control':'no-store'})

class Backup(BaseModel):
 format:str
 projects:list[dict]=Field(max_length=5000)

@app.post('/api/restore')
def restore(backup:Backup,_=Depends(require_owner)):
 if backup.format!='a2z-project-backup-v1':raise HTTPException(422,'Unsupported backup format')
 validated=[]
 for entry in backup.projects:
  try:
   p=Project(title=entry['title'],kind=entry['kind'],content=entry['content']['text'])
   uuid.UUID(entry['id'])
   validated.append((entry['id'],p.title,p.kind,json.dumps({'text':p.content}),entry['created'],entry['updated']))
  except (KeyError,TypeError,ValueError,ValidationError):raise HTTPException(422,'Invalid project in backup')
 ids=[r[0] for r in validated]
 if len(ids)!=len(set(ids)):raise HTTPException(422,'Duplicate project IDs in backup')
 restored=0
 with connect() as c:
  for row in validated:
   cur=c.execute('INSERT INTO projects (id,title,kind,content,created,updated) VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING',row)
   restored+=cur.rowcount
 return {'restored':restored,'skipped_existing':len(validated)-restored}

app.mount('/',StaticFiles(directory=str(ROOT/'web'),html=True),name='web')
