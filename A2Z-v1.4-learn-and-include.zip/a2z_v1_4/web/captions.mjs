export function validateCues(cues){
 if(!Array.isArray(cues)||cues.length>2000)throw Error('Use no more than 2,000 captions.');
 let end=0;
 return cues.map((c,i)=>{const start=Number(c.start),stop=Number(c.end);if(!Number.isFinite(start)||!Number.isFinite(stop)||start<0||stop<=start||start<end)throw Error(`Caption ${i+1}: use increasing, non-overlapping times with end after start.`);if(typeof c.text!=='string'||!c.text.trim()||c.text.length>2000)throw Error(`Caption ${i+1}: add text (up to 2,000 characters).`);end=stop;return {start,end:stop,text:c.text.trim()}})
}
export function timestamp(n,separator='.'){let ms=Math.round(n*1000);const h=Math.floor(ms/3600000);ms%=3600000;const m=Math.floor(ms/60000);ms%=60000;const s=Math.floor(ms/1000);return [h,m,s].map(x=>String(x).padStart(2,'0')).join(':')+separator+String(ms%1000).padStart(3,'0')}
export function parseCaptions(text){
 const time=t=>{if(!/^(?:\d{2,}:)?\d{2}:\d{2}[.,]\d{3}$/.test(t))throw Error('Use HH:MM:SS.mmm caption timestamps.');const a=t.replace(',','.').split(':').map(Number);if(a.at(-1)>=60||a.at(-2)>=60)throw Error('Caption minutes and seconds must be below 60.');return a.length===3?a[0]*3600+a[1]*60+a[2]:a[0]*60+a[1]};
 const blocks=text.replace(/^\uFEFF/,'').replace(/\r/g,'').trim().split(/\n\s*\n/);const cues=[];
 for(const block of blocks){if(/^(WEBVTT|NOTE|STYLE|REGION)(\s|$)/.test(block))continue;const lines=block.split('\n');const i=lines.findIndex(l=>l.includes('-->'));if(i<0)throw Error('Caption block has no timing line.');const m=lines[i].match(/^(\S+)\s+-->\s+(\S+)(?:\s+.*)?$/);if(!m)throw Error('Invalid caption timing.');cues.push({start:time(m[1]),end:time(m[2]),text:lines.slice(i+1).join('\n')})}
 return validateCues(cues)
}
export function serialize(cues,format='vtt'){cues=validateCues(cues);return (format==='vtt'?'WEBVTT\n\n':'')+cues.map((c,i)=>(format==='srt'?`${i+1}\n`:'')+timestamp(c.start,format==='srt'?',':'.')+' --> '+timestamp(c.end,format==='srt'?',':'.')+'\n'+c.text).join('\n\n')+'\n'}
